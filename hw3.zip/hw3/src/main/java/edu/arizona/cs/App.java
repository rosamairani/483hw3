package edu.arizona.cs;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.BooleanQuery.Builder;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.MatchAllDocsQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.RAMDirectory;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

/**
 * ROSARIO RIVERA
 * Skeleton for HW3
 * Also used 5 min tutorial to build, and stackexchange for help on boolean query
 * 
 * Part 2 of Problem: Scoring strategy is vector based and boolean based. So a combination
 * of both.
 *
 */
public class App
{

	public static void main( String[] args ) throws ParseException, IOException
    {
        // this is just to make sure that the Lucene dependency works
        StandardAnalyzer analyzer = new StandardAnalyzer();

        // replace this with the actual homework :)
        Directory index = new RAMDirectory();

        IndexWriterConfig config = new IndexWriterConfig(analyzer);

        IndexWriter w = new IndexWriter(index, config);
        
        
        System.out.println("Please enter name of file: ");

    	Scanner scan = new Scanner(System.in);
    	String name = scan.next();
    	File text = new File(name);
    	try {
			scan = new Scanner(text);
		} catch (FileNotFoundException e) {
			System.out.println("File does not exist");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	//w.close();
    	while(scan.hasNextLine())
    	{
    		String line = scan.nextLine();
    		
    		
//    		
    		List<String> list = new ArrayList<String>(Arrays.asList(line.split(":")));
    		String last = list.get(list.size()-1);
    		last = last.trim();
    		last = last.substring(1, last.length()-2);
    		String title = list.get(0);
//    		addDoc(w, list.get(0), last);
    		addDoc(w, last, title);
    		
    	}
  
        
        w.close();
        
        System.out.println("Enter Query without AND, AND NOT ");
    	 scan = new Scanner(System.in);
    	String query = scan.next();
        // 2. query
        String querystr = args.length > 0 ? args[0] : query;
        System.out.println();

        Query q = new QueryParser("content", analyzer).parse(querystr);
        querySearch(q,index);
        System.out.println();
        
        
        System.out.println("Next Query is in the format of phrase1 AND phrase2");
        System.out.println("Enter phrase for before AND: ");
        scan = new Scanner(System.in);
    	String and1 = scan.next();
    	System.out.println("Enter phrase for after AND: ");
        scan = new Scanner(System.in);
    	String and2 = scan.next();
    	System.out.println();
    	String querystr2 = "content: "+and1+" AND content:"+and2;
    	Query q2 = new QueryParser("content", analyzer).parse(querystr2);
    	querySearch(q2,index);
    	System.out.println();
    	
    	
    	System.out.println("Next Query is in the format of phrase1 AND NOT phrase2");
        System.out.println("Enter phrase for before AND NOT: ");
        scan = new Scanner(System.in);
    	String not1 = scan.next();
    	System.out.println("Enter phrase after AND NOT: ");
    	scan = new Scanner(System.in);
    	String not2 = scan.next();
    	System.out.println();
    	String querystr3 = "content:"+not1 + "NOT content: " + not2;
    	MatchAllDocsQuery everyDocClause = new MatchAllDocsQuery();
    	TermQuery termClause = new TermQuery(new Term("content", not2));
    	TermQuery termClause2 = new TermQuery(new Term("content", not1));
    	BooleanQuery.Builder q3 = new BooleanQuery.Builder();
    	q3.add(everyDocClause, BooleanClause.Occur.MUST);
    	q3.add(termClause, BooleanClause.Occur.MUST_NOT);
    	q3.add(termClause2, BooleanClause.Occur.MUST);

    	querySearch(q3,index);
    	System.out.println();
    	
    	
    	System.out.println("Next Query is in the format of phrase1 AND phrase2");
    	System.out.println("Enter phrase for before AND. For within 1 word of each other : ");
        scan = new Scanner(System.in);
    	String andwith1 = scan.next();
    	
    	System.out.println("Enter phrase for after AND. For within 1 word of each other : ");
        scan = new Scanner(System.in);
    	String andwith2 = scan.next();
    	System.out.println();
    	String querystr4 = "content:"+andwith1 + " content:" + andwith2+"~1";
    	Query q4 = new QueryParser("content", analyzer).parse(querystr4);
    	querySearch(q4,index);
    	System.out.println();
    	scan.close();
    	
    }
	
	private static void querySearch(Query query, Directory index) throws IOException
	{
        // 3. search
        int hitsPerPage = 10;
        IndexReader reader = DirectoryReader.open(index);
        IndexSearcher searcher = new IndexSearcher(reader);
        TopDocs docs = searcher.search(query, hitsPerPage);
        ScoreDoc[] hits = docs.scoreDocs;    
        
        
        // 4. display results
        System.out.println("Found " + hits.length + " hit(s).");
        for(int i=0;i<hits.length;++i) {
            int docId = hits[i].doc;
            Document d = searcher.doc(docId);
            System.out.println((i + 1) + ". " + d.get("name") + "\t Score:" + hits[i].score);
        }

        reader.close();
	}
	
	private static void querySearch(Builder query, Directory index) throws IOException
	{
        // 3. search
        int hitsPerPage = 10;
        IndexReader reader = DirectoryReader.open(index);
        IndexSearcher searcher = new IndexSearcher(reader);
        TopDocs docs = searcher.search(query.build(), hitsPerPage);
        ScoreDoc[] hits = docs.scoreDocs;

        
        
        
        // 4. display results
        System.out.println("Found " + hits.length + " hit(s).");
        for(int i=0;i<hits.length;++i) {
            int docId = hits[i].doc;
            Document d = searcher.doc(docId);
            System.out.println((i + 1) + ". " + d.get("name") + "\t Score:" + hits[i].score);
        }

        reader.close();
	}

    private static void addDoc(IndexWriter w, String content, String name) throws IOException {
        Document doc = new Document();
        doc.add(new TextField("content", content, Field.Store.YES));

        doc.add(new StringField("name", name, Field.Store.YES));
        w.addDocument(doc);
    }

	
	
	}
